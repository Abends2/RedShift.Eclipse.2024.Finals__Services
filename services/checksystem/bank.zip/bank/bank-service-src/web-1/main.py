from flask import Flask, request, render_template_string, render_template
from routes.models import db, login_manager
from routes.routes_money import money
from routes.routes_user import user
from waf.waf import waf

import socket
import os


# Main
app = Flask(__name__)


# Flask Blueprints register
app.register_blueprint(user)
app.register_blueprint(money)


# Flask-Login module init
login_manager.init_app(app)


# DB and App config
addr = socket.gethostbyname('database')
print("DEBUG: db address: ", addr)


# App Config
app.config["SQLALCHEMY_DATABASE_URI"] = f"postgresql://postgres:postgres@{addr}:5432/bank_db"
app.config["SECRET_KEY"] = str(os.urandom(24).hex())


# DB Init and creation
db.init_app(app)
with app.app_context():
    db.create_all()


# 404 Error Handler
@app.errorhandler(404)
def page_not_found(e):
    error_page = open('../app-1/templates/404.html').read().replace('_PATH_', request.path)
    if waf(request.path):
        return render_template("403.html", title="Blocked"), 403
    else:
        return render_template_string(error_page, title="Not Found"), 404


# Run the application 
if __name__ == "__main__":
    app.run(port=5000, host='0.0.0.0', debug=False)
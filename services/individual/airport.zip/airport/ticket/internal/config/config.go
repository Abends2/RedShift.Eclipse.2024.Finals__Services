package config

// TODO: you can set a config from docker to run this on specific port, with specific mode (dev or prod)

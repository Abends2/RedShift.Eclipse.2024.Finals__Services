from models import db, Users, Cards, Transactions, Exchanges

import subprocess
import socket
import os
from flask import Flask, render_template, abort


app = Flask(__name__)


# DB and App config
addr = socket.gethostbyname('database')
app.config["SQLALCHEMY_DATABASE_URI"] = f"postgresql://postgres:postgres@{addr}:5432/bank_db"
app.config["SECRET_KEY"] = str(os.urandom(24).hex())

db.init_app(app)


# Route: Welcome
@app.route("/", methods=["GET"])
def index():
    return "Welcome to admin page!"


# Route: Check Service
@app.route("/api/check/<service>", methods=["GET"])
def do_ping(service):
    if service == 'db':
        result = subprocess.check_output(["/bin/ping", "-c", "1", "10.0.0.4"])
        return '<pre>' + result.decode() + '</pre>'
    elif service == 'app':
        result = subprocess.check_output(["/bin/ping", "-c", "1", "10.0.0.2"])
        return '<pre>' + result.decode() + '</pre>'
    elif service == 'admin':
        result = subprocess.check_output(["/bin/ping", "-c", "1", "10.0.0.3"])
        return '<pre>' + result.decode() + '</pre>'
    elif service == 'nginx':
        result = subprocess.check_output(["/bin/ping", "-c", "1", "10.0.0.5"])
        return '<pre>' + result.decode() + '</pre>'
    else:
        abort(500)


# Route: Users from DB
@app.route("/api/users", methods=["GET"])
def get_users():
    usr_cur = Users.query.all()

    try:
        return render_template("users.html", usr_data=usr_cur)
    except Exception:
        abort(500)


# Route: User's cards
@app.route("/api/cards/<username>", methods=["GET"])
def get_users_cards(username):
    card_cur = Cards.query.filter_by(username=username).all()
    
    try:
        return render_template("cards.html", cards_data=card_cur)
    except Exception:
        abort(500)


# Route: All Transactions history
@app.route("/api/transactions/<username>", methods=["GET"])
def get_transactions(username):
    tr_cur = Transactions.query.filter_by(username=username).all()
    
    try:
        return render_template("transactions.html", transac_data=tr_cur)
    except Exception:
        abort(500)


# Route: All Exchanges history
@app.route("/api/exchanges", methods=["GET"])
def get_exchanges():
    ex_cur = Exchanges.query.all()
    
    try:
        return render_template("exchanges.html", ex_data=ex_cur)
    except Exception:
        abort(500)


# Run the application 
if __name__ == "__main__":
    app.run(port=8000, host="0.0.0.0", debug=False)
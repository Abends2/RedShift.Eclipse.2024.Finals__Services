# "Negative Tech" Web Application Firewall (WAF L7)
def waf(param):
	signatures = [
		"OR", "SELECT", "UNION", "AND", "or", "select", "union", "and",
		"..", "../", "/../", "..//", "....//", "..../", "script", "iframe", "img", "svg",
	]

	for key, value in enumerate(signatures):
		print(key, value)
		if value in param.strip().lower():
			return True
			break
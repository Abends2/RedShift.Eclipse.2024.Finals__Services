    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <unistd.h>
    #include <sys/types.h>
    #include <time.h>
    #include <signal.h>
    #include <sqlite3.h>

    #include "menu.c"
    #include "database.c"
    #include "update.c"



    #define BUFFER_SIZE 20
    char inputLine[BUFFER_SIZE];
    char currentUserRole[50] = "";

    sqlite3 *db;


int Greetings()
{
    showWelcomeMenu();
    char command[BUFFER_SIZE];
    while (1) {
        printf("> ");
        if (!fgets(command, BUFFER_SIZE, stdin)) {
            // Обработка ошибки ввода
            continue;
        }

        // Удаление символа новой строки
        command[strcspn(command, "\n")] = 0;

        if (strcmp(command, "help") == 0) {
            showGettinghelp();
        } else if (strcmp(command, "login") == 0) {
            if(loginUser(db, currentUserRole))
            {
                return 1;
            }
        } else if (strcmp(command, "registration") == 0) {
            registerNewUser(db);
        } else if (strcmp(command, "exit") == 0) {
            printf("Выход из программы.\n");
            break;
        } else {
            printf("Неизвестная команда. Введите 'help' для списка доступных команд.\n");
        }
    }
    return 0;
}

int main() 
{
        setbuf(stdout, NULL);
        int rc = sqlite3_open("users.db", &db);
        if (rc != SQLITE_OK) 
        {
            fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
            sqlite3_close(db);
            return 1;
        }

        if (!Greetings()) {
            printf("ERROR\n");
            return 0;
        }
        showIntro();
        
        ReactorStatus reactor; // Инициализируем состояние реактора
        initializeReactor(&reactor);

        printf("Application started. Type 'help' for a list of commands.\n Please Write command\n");
    while (1) 
    {
        printf("> ");
        fgets(inputLine, BUFFER_SIZE, stdin); // Используем безопасный fgets вместо gets
        inputLine[strcspn(inputLine, "\n")] = 0; // Удаляем символ новой строки

        if (strcmp(inputLine, "help") == 0) {
            showHelp(currentUserRole);
        } 
        else if (strncmp(inputLine, "say", 3) == 0) {
            // Доступно для всех ролей
            processSayCommand(inputLine + 4);
        }
        else if (strcmp(inputLine, "debug") == 0) printInfo();
        else if(strcmp(inputLine, "exit") == 0) break;
        else if (strcmp(inputLine, "simulate failure") == 0 || strcmp(inputLine, "start") == 0 || strcmp(inputLine, "status") == 0 || strcmp(inputLine, "debug") == 0 || strcmp(inputLine, "write command") == 0) 
        {
            if (strcmp(currentUserRole, "admin") == 0 || strcmp(currentUserRole, "operator") == 0) 
            {
            // Вызов соответствующей функции в зависимости от команды
                if (strcmp(inputLine, "simulate failure") == 0) simulateFailure(&reactor, selectFailureType());
                else if (strcmp(inputLine, "start") == 0) simulateReactorStartup(&reactor);
                else if (strcmp(inputLine, "status") == 0) printStatus(&reactor);
                else if (strcmp(inputLine, "write command") == 0) readAndExecuteCommand(&reactor);
            } else {
                    printf("Insufficient privileges.\n");
            }
        }
        else 
        {
            if (strcmp(currentUserRole, "admin") == 0) 
            {
                if (strcmp(inputLine, "add user") == 0) {
                        char username[50], password[50], role[50];
                        printf("Enter username: ");
                        fgets(username, 50, stdin);
                        username[strcspn(username, "\n")] = 0;

                        printf("Enter password: ");
                        fgets(password, 50, stdin);
                        password[strcspn(password, "\n")] = 0;

                        printf("Enter role: ");
                        fgets(role, 50, stdin);
                        role[strcspn(role, "\n")] = 0;

                        addUser(db, currentUserRole, username, password, role);
                } else if (strcmp(inputLine, "change user role") == 0) {
                    char username[50], role[50];
                        printf("Enter username: ");
                        fgets(username, 50, stdin);
                        username[strcspn(username, "\n")] = 0;

                        printf("Enter new role: ");
                        fgets(role, 50, stdin);
                        role[strcspn(role, "\n")] = 0;

                        changeUserRole(db, currentUserRole, username, role);
                } else if (strcmp(inputLine, "delete user") == 0) {
                    char username[50];
                        printf("Enter username user to delete: ");
                        fgets(username, 50, stdin);
                        username[strcspn(username, "\n")] = 0;
                        deleteUser(db, currentUserRole, username);
                } else if(strcmp(inputLine, "list user") == 0)
                {
                    listUsers(db);
                }
                else if(strcmp(inputLine, "search user") == 0)
                {
                    char username[50];
                    printf("Enter username user to search: ");
                    fgets(username, 50, stdin);
                    username[strcspn(username, "\n")] = 0;
                    findUser(db,username);

                }
                else {
                    printf("Unknown command.\n");
                }
            }
        }

    }
    sqlite3_close(db);
    return 0;
}
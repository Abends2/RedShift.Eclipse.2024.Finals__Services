from flask import Flask, Blueprint, render_template, render_template_string, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required

# SQLAlchemy Init
db = SQLAlchemy()

# Flask Login Manager init
login_manager = LoginManager()


# Users DB model
class Users(UserMixin, db.Model):
    __tablename__ = 'Users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(250), unique=True, nullable=False)
    password = db.Column(db.String(250), nullable=False)
    dollar_balance = db.Column(db.Integer(), nullable=False)
    euro_balance = db.Column(db.Integer(), nullable=False)
    rub_balance = db.Column(db.Integer(), nullable=False)


# User's cards model
class Cards(db.Model):
    __tablename__ = 'Cards'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(250), nullable=False)
    name = db.Column(db.String(250), nullable=False)
    surname = db.Column(db.String(250), nullable=False)
    number = db.Column(db.String(16), nullable=False)
    csv = db.Column(db.String(16), nullable=False)
    pin = db.Column(db.String(16), nullable=False)


# Transactions history
class Transactions(db.Model):
    __tablename__ = 'Transactions'
    id = db.Column(db.Integer, primary_key=True)
    tr_type = db.Column(db.String(40), nullable=False)
    username = db.Column(db.String(250), nullable=False)
    currency_old_1 = db.Column(db.String(250), nullable=False)
    currency_old_2 = db.Column(db.String(250), nullable=False)
    currency_new_1 = db.Column(db.String(250), nullable=False)
    currency_new_2 = db.Column(db.String(250), nullable=False)


# Excahnges history
class Exchanges(db.Model):
    __tablename__ = 'Exchanges'
    id = db.Column(db.Integer, primary_key=True)
    tr_type = db.Column(db.String(40), nullable=False)
    username_1 = db.Column(db.String(250), nullable=False)
    username_2 = db.Column(db.String(250), nullable=False)
    currency_old_1 = db.Column(db.String(250), nullable=False)
    currency_old_2 = db.Column(db.String(250), nullable=False)
    currency_new_1 = db.Column(db.String(250), nullable=False)
    currency_new_2 = db.Column(db.String(250), nullable=False)
    

@login_manager.user_loader
def loader_user(user_id):
    return Users.query.get(user_id)
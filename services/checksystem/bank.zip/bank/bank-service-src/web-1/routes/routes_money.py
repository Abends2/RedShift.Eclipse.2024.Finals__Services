from flask import Flask, Blueprint, render_template, render_template_string, request, url_for, redirect, abort, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required
from routes.models import Users, Cards, Transactions, Exchanges, db

import random


# Money Routes Blueprint
money = Blueprint('money', __name__)


# Luhn card number generator
def generate_luhn_number():
    while True:
        number = random.randint(1000000000000000, 9999999999999999)
        digits = [int(x) for x in str(number)]
        for i in range(len(digits) - 2, -1, -2):
            digits[i] = sum(divmod(digits[i] * 2, 10))
        if sum(digits) % 10 == 0:
            return number


# Route: Currency
@money.route("/currency_rate", methods=["GET"])
@login_required
def currency():
    return render_template("currency.html", username=session['username'], title="Currency")


# Route: Transaction
@money.route("/transactions", methods=["GET", "POST"])
@login_required
def transaction():
    transaction_cur = Users.query.filter_by(username=session['username']).first()

    if request.method == "GET":
        return render_template("transactions.html", title="Transactions", username=session['username'], d=transaction_cur.dollar_balance, e=transaction_cur.euro_balance, r=transaction_cur.rub_balance)
    elif request.method == "POST":
        option = request.form.get("transaction-type")
        
        if option == "dollars-euro":
            return redirect(url_for("money.transaction_dollars_euro"))
        elif option == "euro-dollars":
            return redirect(url_for("money.transaction_euro_dollars"))
        elif option == "euro-rubbles":
            return redirect(url_for("money.transaction_euro_rub"))
        elif option == "rubbles-euro":
            return redirect(url_for("money.transaction_rub_euro"))
        elif option == "rubbles-dollars":
            return redirect(url_for("money.transaction_rub_dollars"))
        elif option == "dollars-rubbles":
            return redirect(url_for("money.transaction_dollars_rub"))
        else:
            return abort(500)
    else:
        return abort(500)


# Route: usd_to_euro
@money.route("/transactions/usd_to_euro", methods=["GET", "POST"])
@login_required
def transaction_dollars_euro():
    transaction_cur = Users.query.filter_by(username=session['username']).first()
    if request.method == "GET":
        return render_template("usd_to_euro.html", title="Transactions", username=session['username'], d=transaction_cur.dollar_balance, e=transaction_cur.euro_balance, r=transaction_cur.rub_balance)
    elif request.method == "POST":
        usr = session["username"]
        dollars = int(request.form.get("dollars"))

        if dollars < 0:
            return abort(500)
        elif dollars <= transaction_cur.dollar_balance:
            new_euro_balance = dollars * 0.928023 + transaction_cur.euro_balance
            new_dollar_balance = transaction_cur.dollar_balance - dollars
                    
            tr_cur = Transactions(
                tr_type = 'usd_to_euro',
                username = f'{usr}',
                currency_old_1 = f'{transaction_cur.dollar_balance} $',
                currency_old_2 = f'{transaction_cur.euro_balance} €',
                currency_new_1 = f'{new_dollar_balance} $',
                currency_new_2 = f'{new_euro_balance} €'
            )

            transaction_cur.euro_balance = new_euro_balance
            transaction_cur.dollar_balance = new_dollar_balance

            db.session.add(tr_cur)
            db.session.commit()
            return redirect(url_for("user.profile", username=session["username"]))
        else:
            return abort(500)
        return abort(500)


# Route: euro_to_usd
@money.route("/transactions/euro_to_usd", methods=["GET", "POST"])
@login_required
def transaction_euro_dollars():
    transaction_cur = Users.query.filter_by(username=session['username']).first()
    if request.method == "GET":
        return render_template("euro_to_usd.html", title="Transactions", username=session['username'], d=transaction_cur.dollar_balance, e=transaction_cur.euro_balance, r=transaction_cur.rub_balance)
    elif request.method == "POST":
        usr = session["username"]
        euro = int(request.form.get("euro"))

        if euro < 0:
            return abort(500)
        elif euro <= transaction_cur.euro_balance:
            new_dollar_balance = euro * 1.08 + transaction_cur.dollar_balance
            new_euro_balance = transaction_cur.euro_balance - euro

            tr_cur = Transactions(
                tr_type = 'euro_to_usd',
                username = f'{usr}',
                currency_old_1 = f'{transaction_cur.euro_balance} €',
                currency_old_2 = f'{transaction_cur.dollar_balance} $',
                currency_new_1 = f'{new_euro_balance} €',
                currency_new_2 = f'{new_dollar_balance} $'
            )

            transaction_cur.euro_balance = new_euro_balance
            transaction_cur.dollar_balance = new_dollar_balance

            db.session.add(tr_cur)
            db.session.commit()
            return redirect(url_for("user.profile", username=session["username"]))
        else:
            return abort(500)
        return abort(500)


# Route: euro_to_rub
@money.route("/transactions/euro_to_rub", methods=["GET", "POST"])
@login_required
def transaction_euro_rub():
    transaction_cur = Users.query.filter_by(username=session['username']).first()
    if request.method == "GET":
        return render_template("euro_to_rub.html", title="Transactions", username=session['username'], d=transaction_cur.dollar_balance, e=transaction_cur.euro_balance, r=transaction_cur.rub_balance)
    elif request.method == "POST":
        usr = session["username"]
        euro = int(request.form.get("euro"))

        if euro < 0:
            return abort(500)
        elif euro <= transaction_cur.euro_balance:
            new_rub_balance = euro * 99.53 + transaction_cur.rub_balance
            new_euro_balance = transaction_cur.euro_balance - euro

            tr_cur = Transactions(
                tr_type = 'euro_to_rub',
                username = f'{usr}',
                currency_old_1 = f'{transaction_cur.euro_balance} €',
                currency_old_2 = f'{transaction_cur.rub_balance} ₽',
                currency_new_1 = f'{new_euro_balance} €',
                currency_new_2 = f'{new_rub_balance} ₽'
            )

            transaction_cur.rub_balance = new_rub_balance
            transaction_cur.euro_balance = new_euro_balance

            db.session.add(tr_cur)
            db.session.commit()
            return redirect(url_for("user.profile", username=session["username"]))
        else:
            return abort(500)
        return abort(500)


# Route: rub_to_euro
@money.route("/transactions/rub_to_euro", methods=["GET", "POST"])
@login_required
def transaction_rub_euro():
    transaction_cur = Users.query.filter_by(username=session['username']).first()
    if request.method == "GET":
        return render_template("rub_to_euro.html", title="Transactions", username=session['username'], d=transaction_cur.dollar_balance, e=transaction_cur.euro_balance, r=transaction_cur.rub_balance)
    elif request.method == "POST":
        usr = session["username"]
        rubbles = int(request.form.get("rubbles"))

        if rubbles < 0:
            return abort(500)
        elif rubbles <= transaction_cur.rub_balance:
            new_euro_balance = rubbles * 0.010047 + transaction_cur.euro_balance
            new_rub_balance = transaction_cur.rub_balance - rubbles

            tr_cur = Transactions(
                tr_type = 'rub_to_euro',
                username = f'{usr}',
                currency_old_1 = f'{transaction_cur.rub_balance} ₽',
                currency_old_2 = f'{transaction_cur.euro_balance} €',
                currency_new_1 = f'{new_rub_balance} ₽',
                currency_new_2 = f'{new_euro_balance} €'
            )

            transaction_cur.euro_balance = new_euro_balance 
            transaction_cur.rub_balance = new_rub_balance

            db.session.add(tr_cur)
            db.session.commit()
            return redirect(url_for("user.profile", username=session["username"]))
        else:
            return abort(500)
        return abort(500)


# Route: rub_to_usd
@money.route("/transactions/rub_to_usd", methods=["GET", "POST"])
@login_required
def transaction_rub_dollars():
    transaction_cur = Users.query.filter_by(username=session['username']).first()
    if request.method == "GET":
        return render_template("rub_to_usd.html", title="Transactions", username=session['username'], d=transaction_cur.dollar_balance, e=transaction_cur.euro_balance, r=transaction_cur.rub_balance)
    elif request.method == "POST":
        usr = session["username"]
        rubbles = int(request.form.get("rubbles"))

        if rubbles < 0:
            return abort(500)
        elif rubbles <= transaction_cur.rub_balance:
            new_dollar_balance = rubbles * 0.010826 + transaction_cur.dollar_balance
            new_rub_balance = transaction_cur.rub_balance - rubbles

            tr_cur = Transactions(
                tr_type = 'rub_to_usd',
                username = f'{usr}',
                currency_old_1 = f'{transaction_cur.rub_balance} ₽',
                currency_old_2 = f'{transaction_cur.dollar_balance} $',
                currency_new_1 = f'{new_rub_balance} ₽',
                currency_new_2 = f'{new_dollar_balance} $'
            )

            transaction_cur.dollar_balance = new_dollar_balance 
            transaction_cur.rub_balance = new_rub_balance

            db.session.add(tr_cur)
            db.session.commit()
            return redirect(url_for("user.profile", username=session["username"]))
        else:
            return abort(500)
        return abort(500)


# Route: usd_to_rub
@money.route("/transactions/usd_to_rub", methods=["GET", "POST"])
@login_required
def transaction_dollars_rub():
    transaction_cur = Users.query.filter_by(username=session['username']).first()
    if request.method == "GET":
        return render_template("usd_to_rub.html", title="Transactions", username=session['username'], d=transaction_cur.dollar_balance, e=transaction_cur.euro_balance, r=transaction_cur.rub_balance)
    elif request.method == "POST":
        usr = session["username"]
        dollars = int(request.form.get("dollars"))

        if dollars <= transaction_cur.dollar_balance:
            new_rub_balance = dollars * 92.37 + transaction_cur.rub_balance
            new_dollar_balance = transaction_cur.dollar_balance - dollars

            tr_cur = Transactions(
                tr_type = 'usd_to_rub',
                username = f'{usr}',
                currency_old_1 = f'{transaction_cur.dollar_balance} $',
                currency_old_2 = f'{transaction_cur.rub_balance} ₽',
                currency_new_1 = f'{new_dollar_balance} $',
                currency_new_2 = f'{new_rub_balance} ₽'
            )
            
            transaction_cur.rub_balance = new_rub_balance
            transaction_cur.dollar_balance = new_dollar_balance
            
            db.session.add(tr_cur)
            db.session.commit()
            return redirect(url_for("user.profile", username=session["username"]))
        else:
            return abort(500)
        return abort(500)


# Route: Exchanges
@money.route("/exchanges", methods=["GET", "POST"])
@login_required
def exchange():
    if request.method == "GET":
        return render_template("exchanges.html")
    elif request.method == "POST":
        usr = session["username"]
        other_username = request.form.get("other")
        money_count = request.form.get("money-count")
        transaction_type = request.form.get("transaction-type")
        
        try:
            logged_user_account = Users.query.filter_by(username=session['username']).first()
            other_user_account = Users.query.filter_by(username=other_username).first()

            if transaction_type == "dollars":
                new_balance_other_user = other_user_account.dollar_balance + int(money_count)
                new_balance_logged_user = logged_user_account.dollar_balance - int(money_count)
                    
                ex_cur = Exchanges(
                    tr_type = 'dollars',
                    username_1 = f'{usr}',
                    username_2 = f'{other_user_account.username}',
                    currency_old_1 = f'{logged_user_account.dollar_balance} $',
                    currency_old_2 = f'{other_user_account.dollar_balance} $',
                    currency_new_1 = f'{new_balance_logged_user} $',
                    currency_new_2 = f'{new_balance_other_user} $'
                )

                logged_user_account.dollar_balance = new_balance_logged_user
                other_user_account.dollar_balance = new_balance_other_user

                db.session.add(ex_cur)
                db.session.commit()
                return redirect(url_for("user.profile", username=session["username"]))
            elif transaction_type == "euro":
                new_balance_other_user = other_user_account.euro_balance + int(money_count)
                new_balance_logged_user = logged_user_account.euro_balance - int(money_count)

                ex_cur = Exchanges(
                    tr_type = 'euro',
                    username_1 = f'{usr}',
                    username_2 = f'{other_user_account.username}',
                    currency_old_1 = f'{logged_user_account.euro_balance} €',
                    currency_old_2 = f'{other_user_account.euro_balance} €',
                    currency_new_1 = f'{new_balance_logged_user} €',
                    currency_new_2 = f'{new_balance_other_user} €'
                )
                    
                logged_user_account.euro_balance = new_balance_logged_user
                other_user_account.euro_balance = new_balance_other_user

                db.session.add(ex_cur)
                db.session.commit()
                return redirect(url_for("user.profile", username=session["username"]))
            elif transaction_type == "rubbles":
                new_balance_other_user = other_user_account.rub_balance + int(money_count)
                new_balance_logged_user = logged_user_account.rub_balance - int(money_count)

                ex_cur = Exchanges(
                    tr_type = 'rubbles',
                    username_1 = f'{usr}',
                    username_2 = f'{other_user_account.username}',
                    currency_old_1 = f'{logged_user_account.rub_balance} ₽',
                    currency_old_2 = f'{other_user_account.rub_balance} ₽',
                    currency_new_1 = f'{new_balance_logged_user} ₽',
                    currency_new_2 = f'{new_balance_other_user} ₽'
                )
                    
                logged_user_account.rub_balance = new_balance_logged_user
                other_user_account.rub_balance = new_balance_other_user

                db.session.add(ex_cur)
                db.session.commit()
                return redirect(url_for("user.profile", username=session["username"]))
            else:
                return abort(400)
        except:
            return abort(500)


# Route: Create Card
@money.route("/create_card", methods=["GET", "POST"])
@login_required
def create_card():
    if request.method == "GET":
        return render_template("create_card.html", title="Cards")
    elif request.method == "POST":
        name = request.form.get("name")
        surname = request.form.get("surname")
        pin = request.form.get("pin")
        usr = session['username']
        number = str(generate_luhn_number())
        csv_code = random.randint(100, 999)

        cards_cur = Cards(
            username = f'{usr}',
            name = f'{name}',
            surname = f'{surname}',
            number = f'{number}',
            csv = f'{csv_code}',
            pin = f'{pin}'
        )

        db.session.add(cards_cur)
        db.session.commit()

        chunks, chunk_size = len(number), 4
        card_octets = [number[i:i+chunk_size] for i in range(0, chunks, chunk_size)]

        return render_template("cards.html", username=session['username'], title="Personal Card", name=name, surname=surname, csv=csv_code, oct_1=card_octets[0], oct_2=card_octets[1], oct_3=card_octets[2], oct_4=card_octets[3])
    else:
        abort(500)


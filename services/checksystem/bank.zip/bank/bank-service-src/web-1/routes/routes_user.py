from flask import Flask, Blueprint, render_template, render_template_string, request, url_for, redirect, session, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required
from routes.models import Users, Cards, db
from waf.waf import waf

import requests


# User Routes Blueprint
user = Blueprint('user', __name__)


# Route: Register User
@user.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "POST":
        user = Users(
            username=request.form.get("username"),
            password=request.form.get("password"),
            dollar_balance=1000,
            euro_balance=1500,
            rub_balance=100000
        )
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("user.login"))
    return render_template("register.html")


# Route: Login User
# НАПИСАТЬ ПРОВЕРКУ НА КРЕДЫ
@user.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = Users.query.filter_by(username=request.form.get("username")).first()
        if user.password == request.form.get("password"):
            login_user(user)
            session['username'] = request.form.get("username")
            return redirect(url_for("user.home"))
    return render_template("login.html")


# Route: Logout User
@user.route("/logout")
@login_required
def logout():
    logout_user()
    session.pop('username', None)
    return redirect(url_for("user.root"))


# Route: Home
@user.route("/home", methods=['GET', 'POST'])
@login_required
def home():
    return render_template("home.html", username=session['username'], title="Home")


# Route: Root
@user.route("/", methods=["GET"])
def root():
    return render_template("welcome.html")


# Route: Search
@user.route("/search", methods=['GET', 'POST'])
@login_required
def search():
    if request.method == 'GET':
        return render_template("search.html", username=session['username'], title="Search")
    elif request.method == 'POST':
        param = request.form.get("search-param")

        if waf(param):
            return render_template("403.html", title="Blocked")
        elif "http://" in param:
            try:
                response = requests.get(param)
                return response.text
            except:
                return abort(404)
        elif param:
            return f"<h1 class='list1'>Found: { param }</h1>"
        else:
            return abort(500)


# Route: User's profile
@user.route("/profile/<username>")
@login_required
def profile(username):
    user_cur = Users.query.filter_by(username=username).first()
    try:
        return render_template('profile.html', username=user_cur.username, title="Profile", d=user_cur.dollar_balance, e=user_cur.euro_balance, r=user_cur.rub_balance)
    except AttributeError:
        return render_template('404.html', username=username, title="404")
void showIntro() {
        printf("           .-.     .-.     .-.           \n");
        printf("      _   (_) )   (_) )   (_) )   _       \n");
        printf("     | |  |_/     |_/     |_/    | |      \n");
        printf("     | |  |||     |||     |||    | |      \n");
        printf("     | |  |||     |||     |||    | |      \n");
        printf("     | |  |||     |||     |||    | |      \n");
        printf("     | |  |||     |||     |||    | |      \n");
        printf("     | |  |||     |||     |||    | |      \n");
        printf("     | |  |||     |||     |||    | |      \n");
        printf("     | | _|||_   _|||_   _|||_   | |      \n");
        printf("     | |/ \\|/ \\ / \\|/ \\ / \\|/ \\  | |      \n");
        printf("     | ||\\_/|\\_/|\\_/|\\_/|\\_/|\\_ | |      \n");
        printf("     | |                           | |      \n");
        printf("   __|_|___________________________|_|__    \n");
        printf("  '---'                           '---'   \n");
        printf("\n");
        printf("        Welcome to ECLIPSE                \n");
        printf("  Nuclear Power Plant Control Console     \n");
        printf("------------------------------------------\n\n");
}

void showWelcomeMenu() {
    printf("\n");
    printf("-------------------------------------------------\n");
    printf("|                                               |\n");
    printf("|                 Приветствуем!                 |\n");
    printf("|                                               |\n");
    printf("|                  _______                      |\n");
    printf("|                 /       \\                     |\n");
    printf("|                |   ___   |                    |\n");
    printf("|                |  /   \\  |                    |\n");
    printf("|                | |     | |                    |\n");
    printf("|                |  \\___/  |                    |\n");
    printf("|                |         |                    |\n");
    printf("|                 \\_______/                     |\n");
    printf("|                                               |\n");
    printf("|   Введите 'login' для авторизации.            |\n");
    printf("|                                               |\n");
    printf("-------------------------------------------------\n");
    printf("\n");
}


void processSayCommand(char* message) {
        printf("Message: %s\n", message);
}
void showGeneralHelp() {
    printf("- help: Показать это меню помощи.\n");
    printf("- say <сообщение>: Вывести сообщение. Доступно для всех ролей.\n");
    printf("- exit: Выйти из программы.\n");
}

void showAdminAndOperatorHelp() {
    showGeneralHelp(); // Показываем общие команды доступные всем пользователям
    printf("- simulate failure: Симулировать неисправность.\n");
    printf("- start: Запустить симуляцию.\n");
    printf("- status: Показать статус.\n");
    printf("- write command: Выполнить записанную команду.\n");
}
void showAdminHelp() {
    showAdminAndOperatorHelp(); // Показываем команды доступные для admin и operator
    printf("- add user: Добавить пользователя.\n");
    printf("- change user role: Изменить роль пользователя.\n");
    printf("- delete user: Удалить пользователя.\n");
    printf("- list user : Вывести список всех пользователей.\n");
    printf("- search user: Поиск по имени пользователя.\n");
}


void showGettinghelp() {
    printf("Доступные команды:\n");
    printf("help - Показать список доступных команд.\n");
    printf("login - Войти в систему.\n");
    printf("registration - Зарегистрировать нового пользователя.\n");
    printf("exit - Выйти из программы.\n");
}

void showHelp(char *currentUserRole) {   
        if (strcmp(currentUserRole, "admin") == 0)
        {
            showAdminHelp();
        }
        else if(strcmp(currentUserRole, "operator") == 0)
        {
            showAdminAndOperatorHelp();
        }
        else
        {   
            showGeneralHelp();
        }
}

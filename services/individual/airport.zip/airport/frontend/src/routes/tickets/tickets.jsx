function Tickets() {
    return <h1>Tickets Page</h1>;
}

export default Tickets;
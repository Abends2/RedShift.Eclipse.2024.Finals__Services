#include <stdio.h>
#include <stdlib.h>
#include <sqlite3.h>
#include <openssl/sha.h>
#include <string.h>


void hashPassword(const char *password, char *outputBuffer) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, password, strlen(password));
    SHA256_Final(hash, &sha256);
    
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        sprintf(outputBuffer + (i * 2), "%02x", hash[i]);
    }
    outputBuffer[64] = 0;
}

int registerUser(sqlite3* db, const char* username, const char* password, const char* role) {
    char* errMsg = 0;
    int rc;
    char hashString[65];

    hashPassword(password, hashString);

    sqlite3_stmt* stmt;
    const char* sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?);";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        fprintf(stderr, "Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return 0 ;
    }

    sqlite3_bind_text(stmt, 1, username, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, hashString, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, role, -1, SQLITE_STATIC);

    rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        printf("ERROR inserting data: %s\n", sqlite3_errmsg(db));
        return 0;
    } else {
        sqlite3_finalize(stmt);
        printf("User registered successfully\n");
        return 1;
    }
}

void registerNewUser(sqlite3* db) {
    char username[50];
    char password[50];
    const char* role = "user"; // Роль по умолчанию для всех новых пользователей

    printf("Введите имя нового пользователя: ");
    if (fgets(username, sizeof(username), stdin) == NULL) {
        printf("Ошибка ввода.\n");
        return;
    }
    username[strcspn(username, "\n")] = 0; // Удаляем символ новой строки

    printf("Введите пароль: ");
    if (fgets(password, sizeof(password), stdin) == NULL) {
        printf("Ошибка ввода.\n");
        return;
    }
    password[strcspn(password, "\n")] = 0; // Удаляем символ новой строки

    // Вызов функции registerUser для добавления     нового пользователя в базу данных
    int result = registerUser(db, username, password, role = "admin");
    if (result == 1) {
        printf("Пользователь '%s' успешно зарегистрирован с ролью ''.\n", username);
    } else {
        printf("Не удалось зарегистрировать пользователя '%s'.\n", username);
    }
}


int authenticateUser(sqlite3* db, const char* username, const char* password, char* userRole) {
    int rc;
    char hashString[65];
    char dbHashString[65] = {0};

    hashPassword(password, hashString);

    // Уязвимый SQL запрос, который позволяет SQL инъекции из-за прямого включения входных данных
    char sql[256];
    sprintf(sql, "SELECT password_hash, role FROM users WHERE username = '%s'", username);
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        fprintf(stderr, "Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return 0;
    }

    int step = sqlite3_step(stmt);
    if (step == SQLITE_ROW) {
        strcpy(dbHashString, (const char*)sqlite3_column_text(stmt, 0));
        strcpy(userRole, (const char*)sqlite3_column_text(stmt, 1));
    }

    sqlite3_finalize(stmt);

    if (strcmp(dbHashString, hashString) == 0) {
        return 1; // Authentication successful
    } else {
        return 0; // Authentication failed
    }
}

void findUser(sqlite3* db, const char* username) {
    sqlite3_stmt* stmt;
    // Подготовленный SQL-запрос для поиска пользователя по имени
    const char* sql = "SELECT username, role FROM users WHERE username = ?";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) == SQLITE_OK) {
        // Привязываем значение username к SQL-запросу
        sqlite3_bind_text(stmt, 1, username, -1, SQLITE_STATIC);

        if (sqlite3_step(stmt) == SQLITE_ROW) {
            const char* foundUsername = (const char*)sqlite3_column_text(stmt, 0);
            const char* role = (const char*)sqlite3_column_text(stmt, 1);
            printf("%s - %s\n", foundUsername, role);
        } else {
            printf("Пользователь с именем '%s' не найден.\n", username);
        }
        sqlite3_finalize(stmt);
    } else {
        fprintf(stderr, "Ошибка при поиске пользователя: %s\n", sqlite3_errmsg(db));
    }
}
void listUsers(sqlite3* db) {
    printf("start list userts\n");
    sqlite3_stmt* stmt;
    const char* sql = "SELECT username, role FROM users ORDER BY role, username";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) == SQLITE_OK) {
        printf("Список пользователей:\n");
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            const char* username = (const char*)sqlite3_column_text(stmt, 0);
            const char* role = (const char*)sqlite3_column_text(stmt, 1);
            printf("%s - %s\n", username, role);
        }
        sqlite3_finalize(stmt);
    } else {
        fprintf(stderr, "Ошибка при получении списка пользователей: %s\n", sqlite3_errmsg(db));
    }
}

int changeUserRole(sqlite3* db, const char* adminRole, const char* username, const char* newRole) {
    // Проверяем, является ли текущий пользователь администратором
    if (strcmp(adminRole, "admin") != 0) {
        printf("Только администратор может изменять роли.\n");
        return 0;
    }

    const char* sql = "UPDATE users SET role = ? WHERE username = ?";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        fprintf(stderr, "Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return 0;
    }

    sqlite3_bind_text(stmt, 1, newRole, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, username, -1, SQLITE_STATIC);

    int rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        printf("Ошибка при изменении роли: %s\n", sqlite3_errmsg(db));
        return 0;
    } else {
        printf("Роль пользователя успешно изменена.\n");
        return 1;
    }

    sqlite3_finalize(stmt);
}

int deleteUser(sqlite3* db, const char* adminRole, const char* username) {
    // Проверяем, является ли текущий пользователь администратором
    if (strcmp(adminRole, "admin") != 0) {
        printf("Только администратор может удалять пользователей.\n");
        return 0;
    }

    const char* sql = "DELETE FROM users WHERE username = ?";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        fprintf(stderr, "Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return 0;
    }

    sqlite3_bind_text(stmt, 1, username, -1, SQLITE_STATIC);

    int rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        printf("Ошибка при удалении пользователя: %s\n", sqlite3_errmsg(db));
        return 0;
    } else {
        printf("Пользователь успешно удален.\n");
        return 1;
    }

    sqlite3_finalize(stmt);
}

int getRolePriority(const char* role) {
    if (strcmp(role, "admin") == 0) return 3;
    if (strcmp(role, "operator") == 0) return 2;
    if (strcmp(role, "user") == 0) return 1;
    return 0; // Неизвестная роль
}

int addUser(sqlite3* db, const char* currentAdminRole, const char* username, const char* password, const char* newRole) {
    if (getRolePriority(currentAdminRole) <= getRolePriority(newRole) && getRolePriority(currentAdminRole) != 3){
        printf("Недостаточно прав для создания пользователя с такой ролью.\n");
        return 0;
    }

    char hashString[65];
    hashPassword(password, hashString);

    const char* sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?);";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        fprintf(stderr, "Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return 0;
    }

    sqlite3_bind_text(stmt, 1, username, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, hashString, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, newRole, -1, SQLITE_STATIC);

    int rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        printf("Ошибка при добавлении пользователя: %s\n", sqlite3_errmsg(db));
        sqlite3_finalize(stmt);
        return 0;
    }

    printf("Пользователь успешно добавлен.\n");
    sqlite3_finalize(stmt);
    return 1;
}
loginUser(sqlite3* db, char* currentUserRole) {
    char username[50];
    char password[50];
    printf("Username: ");
    fgets(username, sizeof(username), stdin);
    username[strcspn(username, "\n")] = 0; // Удаление символа новой строки

    printf("Password: ");
    fgets(password, sizeof(password), stdin);
    password[strcspn(password, "\n")] = 0; // Удаление символа новой строки
    printf("login creadse username: %s password: ", username);
    printf(password);
    printf("\n");
    // Использование функции authenticateUser для проверки учетных данных и получения роли пользователя
    if (authenticateUser(db,username, password, currentUserRole)) {
        printf("User '%s' logged %s.\n", username);
        return 1;
        // Теперь можно использовать userRole для управления доступом к различным частям программы в зависимости от роли пользователя
    } else {
        printf("Login to User '%s' failed. Check username and password%s\n",username);
        return 0;
    }
}
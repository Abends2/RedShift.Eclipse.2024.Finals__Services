#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>



#define TEMP_INCREMENT 5
#define PRESSURE_INCREMENT 3
#define RADIATION_INCREMENT 1
#define MAX_POWER_LEVEL 100

// void testFUNC()
//     {
//         if(SIGSEGV) 
//         {
//             printf("%lx",counter);
//             exit(0);
//         }   
//         printf("%lx",counter);
//         return;
//         // после будет добавленно заполнение реактора с последующим взрывом

//     }


typedef enum {NORMAL, WARNING, CRITICAL, SHUTDOWN} SafetyLevel;

typedef struct {
    int temperature;
    int pressure;
    char weather[20];
    int powerLevel;
    int radiation;
    int coolingEfficiency;
    SafetyLevel safetyLevel;
} ReactorStatus;

typedef enum {
    OVERHEAT,         // Перегрев
    PRESSURE_LOSS,    // Потеря давления
    RADIATION_SPIKE,  // Всплеск радиации
    COOLING_FAILURE   // Сбой системы охлаждения
} FailureType;


SafetyLevel NoUsercalculateSafetyLevel(int temp, int pressure, int radiation, int* coolingEfficiency);
void displayASCIIReactor(SafetyLevel level);


FailureType abrams() {
    char buffer_to_write[100];
    int choice;
    long counter = 0x203;
    printf("\nSelect failure type to simulate:\n");
    printf("1 - Overheat\n");
    printf("2 - Pressure Loss\n");
    printf("3 - Radiation Spike\n");
    printf("4 - Cooling System Failure\n");
    printf("Enter your choice (1-4): ");
    if(0)
    {
        scanf("%ld", &choice);
        
    }
    else
    {
        gets(buffer_to_write); // Считываем строку
        sscanf(buffer_to_write, "%d", &choice); // П
      
    }

    printf("Code to ascses %d", counter);

    FailureType buffer[4] = {OVERHEAT,PRESSURE_LOSS,RADIATION_SPIKE,COOLING_FAILURE};
    
    switch (choice) {
        case 1:
            return OVERHEAT;
        case 2:
            return PRESSURE_LOSS;
        case 3:
            return RADIATION_SPIKE;
        case 4:
            return COOLING_FAILURE;
        default:
            printf("Invalid choice, defaulting to Overheat.\n");
            return OVERHEAT;
    }
}
FailureType selectFailureType() {
    char buffer_to_write[100];
    int choice;
    long counter = 0x203;
    printf("\nSelect failure type to simulate:\n");
    printf("1 - Overheat\n");
    printf("2 - Pressure Loss\n");
    printf("3 - Radiation Spike\n");
    printf("4 - Cooling System Failure\n");
    printf("Enter your choice (1-4): ");
    if(0)
    {
        scanf("%ld", &choice);
        
    }
    else
    {
        char buffer[100];
        gets(buffer); // Считываем строку
        sscanf(buffer, "%d", &choice); // П
    }
    printf("Code to ascses %d\n", counter);
    FailureType buffer[4] = {OVERHEAT,PRESSURE_LOSS,RADIATION_SPIKE,COOLING_FAILURE};
    return *(buffer + choice - 1);

    switch (choice) {
        case 1:
            return OVERHEAT;
        case 2:
            return PRESSURE_LOSS;
        case 3:
            return RADIATION_SPIKE;
        case 4:
            return COOLING_FAILURE;
        default:
            printf("Ivalid choice, defaulting to Overheant.\n");
            return OVERHEAT;
    }
}


void simulateFailure(ReactorStatus *reactor, FailureType type) {
    switch (type) {
        case OVERHEAT:
            printf("\nSimulating Overheat...\n");
            reactor->temperature += TEMP_INCREMENT * 10; // Симуляция резкого повышения температуры
            break;
        case PRESSURE_LOSS:
            printf("\nSimulating Pressure Loss...\n");
            reactor->pressure -= PRESSURE_INCREMENT * 5; // Симуляция резкого падения давления
            if (reactor->pressure < 0) reactor->pressure = 0;
            break;
        case RADIATION_SPIKE:
            printf("\nSimulating Radiation Spike...\n");
            reactor->radiation += RADIATION_INCREMENT * 10; // Симуляция всплеска радиации
            break;
        case COOLING_FAILURE:
            printf("\nSimulating Cooling System Failure...\n");
            reactor->coolingEfficiency -= 20; // Симуляция сбоя системы охлаждения
            if (reactor->coolingEfficiency < 0) reactor->coolingEfficiency = 0;
            break;
        default:
            printf("\nUnknown failure type - %d.\n",type);
    }

    // Пересчет уровня безопасности после симуляции сбоя
    reactor->safetyLevel = NoUsercalculateSafetyLevel(reactor->temperature, reactor->pressure, reactor->radiation, &(reactor->coolingEfficiency));
    displayASCIIReactor(reactor->safetyLevel); // Визуализация состояния реактора

    if (reactor->safetyLevel == CRITICAL) {
        printf("[EMERGENCY] Critical safety level reached!\n");
    }
}


const char* safetyLevelToString(SafetyLevel level) {
    switch (level) {
        case NORMAL: return "NORMAL";
        case WARNING: return "WARNING";
        case CRITICAL: return "CRITICAL";
        case SHUTDOWN: return "SHUTDOWN";
        default: return "UNKNOWN";
    }
}

void logEvent(const char* event, SafetyLevel level) {
    time_t now = time(NULL);
    char* timeStr = ctime(&now);
    timeStr[strlen(timeStr)-1] = '\0'; // Удаляем символ новой строки
    printf("[%s] %s - %s\n", safetyLevelToString(level), timeStr, event);
}

void displayASCIIReactor(SafetyLevel level) {
    switch (level) {
        case CRITICAL:
            printf("!! CRITICAL !!\n");
            break;
        case SHUTDOWN:
            printf("** SHUTDOWN **\n");
            break;
        case WARNING:
            printf("!! WARNING !!\n");
            break;
        case NORMAL:
            printf("-- NORMAL --\n");
            break;
        default:
            printf("-- UNKNOWN --\n");
            break;
    }
}

int printInfo() {
    char command[256];
    printf("Enter command to execute: ");
    if (fgets(command, sizeof(command), stdin) != NULL) {
        
        command[strcspn(command, "\n")] = 0;

        
        int result = system(command);
        if (result == -1) {

            printf("Failed to execute command.\n");
            return 0;
        }
        else
        {
            return 1;
        }
    } else {

        printf("Error reading command.\n");
        return 0;
    }
}
void initializeReactor(ReactorStatus *reactor) {
    reactor->temperature = 25;
    reactor->pressure = 1;
    strcpy(reactor->weather, "Clear");
    reactor->powerLevel = 0;
    reactor->radiation = 0;
    reactor->coolingEfficiency = 0;
    reactor->safetyLevel = NORMAL;
}

void printStatus(const ReactorStatus *reactor) {
    printf("\nCurrent Reactor Status:\n");
    printf("Temperature: %d°C (Increment: %+d°C per adjustment)\n", reactor->temperature, TEMP_INCREMENT);
    printf("Pressure: %d atm (Increment: %+d atm per adjustment)\n", reactor->pressure, PRESSURE_INCREMENT);
    printf("Weather: %s\n", reactor->weather);
    printf("Power Level: %d%% (Max level: %d%%)\n", reactor->powerLevel, MAX_POWER_LEVEL);
    printf("Radiation: %dmSv (Increment: %+dmSv per adjustment)\n", reactor->radiation, RADIATION_INCREMENT);
    printf("Cooling Efficiency: %d%%\n", reactor->coolingEfficiency); // Предполагаем, что coolingEfficiency измеряется в процентах
    printf("Safety Level: %s\n", safetyLevelToString(reactor->safetyLevel));
}


void adjustReactorParameters(ReactorStatus *reactor, int adjustment) {
    reactor->temperature += adjustment;
    reactor->pressure += adjustment / 2;
    reactor->radiation += adjustment > 20 ? 1 : 0;
    if (adjustment > 20) {
        strcpy(reactor->weather, "Stormy");
    }
}

void randomEvent(ReactorStatus *reactor) {
    int eventChance = rand() % 100;
    if (eventChance < 20) {
        printf("\n[WARNING] An unexpected event has occurred!\n");
        adjustReactorParameters(reactor, -10);
        printf("[ACTION REQUIRED] Adjust reactor parameters.\n");
    }
}

SafetyLevel calculateSafetyLevel(int temp, int pressure, int radiation, int* coolingEfficiency, int userAdjustment) {
    // Усложненные вычисления с возможностью int overflow
    long tempCalc = (long)temp  * TEMP_INCREMENT - *coolingEfficiency;
    long pressureCalc = (long)pressure  * PRESSURE_INCREMENT + (pressure % 3);
    long radiationCalc = (long)radiation * RADIATION_INCREMENT + (radiation / 2);

    temp = (int)tempCalc;
    pressure = (int)pressureCalc;
    radiation = (int)radiationCalc;
    printf("calculater radiation\n");
    int i;
    for(i = 0; i < userAdjustment; i++)
    {
        radiation *= i;
        radiation /= 10;
        if(radiation < 1)
        {
            radiation = 1;
        }
    } 
    printf("radiation %d\n", i);

    if (temp > 300 || pressure > 150 || radiation > 10) {
        *coolingEfficiency += 3; // Усиленное увеличение эффективности охлаждения в критических условиях
        return CRITICAL;
    } else if ((temp > 250 && temp <= 300) || (pressure > 100 && pressure <= 150) || (radiation > 5 && radiation <= 10)) {
        *coolingEfficiency += 2; // Увеличение эффективности охлаждения
        return WARNING;
    } else if ((temp > 200 && temp <= 250) || (pressure > 50 && pressure <= 100) || (radiation > 3 && radiation <= 5)) {
        *coolingEfficiency += 1; // Незначительное увеличение эффективности охлаждения
        return WARNING;
    } else {
        if (*coolingEfficiency > 0) (*coolingEfficiency)--; // Нормализация эффективности охлаждения
        return NORMAL;
    }
}

SafetyLevel NoUsercalculateSafetyLevel(int temp, int pressure, int radiation, int* coolingEfficiency) {
    // Усложненные вычисления с возможностью int overflow
    long tempCalc = (long)temp  * TEMP_INCREMENT - *coolingEfficiency;
    long pressureCalc = (long)pressure  * PRESSURE_INCREMENT + (pressure % 3);
    long radiationCalc = (long)radiation  * RADIATION_INCREMENT + (radiation / 2);

    // Обновление параметров с использованием безопасного приведения типа
    temp = (int)tempCalc;
    pressure = (int)pressureCalc;
    radiation = (int)radiationCalc;
    printf("calculater radiation\n");
    int i;
    for(i = 0; i < 2; i++)
    {
        radiation *= i;
        radiation /= 10;
        if(radiation < 1)
        {
            radiation = 1;
        }
    } 


    printf("radiation %d\n", i);
    if (temp > 300 || pressure > 150 || radiation > 10) {
        *coolingEfficiency += 3; // Усиленное увеличение эффективности охлаждения в критических условиях
        return CRITICAL;
    } else if ((temp > 250 && temp <= 300) || (pressure > 100 && pressure <= 150) || (radiation > 5 && radiation <= 10)) {
        *coolingEfficiency += 2; // Увеличение эффективности охлаждения
        return WARNING;
    } else if ((temp > 200 && temp <= 250) || (pressure > 50 && pressure <= 100) || (radiation > 3 && radiation <= 5)) {
        *coolingEfficiency += 1; // Незначительное увеличение эффективности охлаждения
        return WARNING;
    } else {
        if (*coolingEfficiency > 0) (*coolingEfficiency)--; // Нормализация эффективности охлаждения
        return NORMAL;
    }
}


void simulateReactorWork(ReactorStatus *reactor)
{
    randomEvent(reactor);

        int adjustment = (rand() % (TEMP_INCREMENT * 2)) - TEMP_INCREMENT;
        adjustReactorParameters(reactor, adjustment);

        reactor->safetyLevel = NoUsercalculateSafetyLevel(reactor->temperature, reactor->pressure, reactor->radiation, &(reactor->coolingEfficiency));
        displayASCIIReactor(reactor->safetyLevel);

        if (reactor->safetyLevel == CRITICAL || reactor->safetyLevel == SHUTDOWN) {
            printf("\n[EMERGENCY SHUTDOWN INITIATED]\n");
            reactor->powerLevel = 0;
        }

        reactor->powerLevel += 10; // Simulate increasing power
        sleep(1);

    if (reactor->powerLevel == 0) {
        printf("\nReactor has been safely shut down.\n");
    } else {
        printf("\nReactor is now operating at full capacity.\n");
    }
}

void simulateReactorStartup(ReactorStatus *reactor) {
    srand((unsigned int)time(NULL));
    initializeReactor(reactor);

    printf("Enter number of uranium rods || : ");
    int userAdjustment;
    scanf("%d", &userAdjustment); // Чтение пользовательского ввода для влияния на параметры реактора

        printStatus(reactor);
        randomEvent(reactor);

        int adjustment = (rand() % (TEMP_INCREMENT * 2)) - TEMP_INCREMENT;
        adjustReactorParameters(reactor, adjustment);
        reactor->safetyLevel = calculateSafetyLevel(reactor->temperature, reactor->pressure, reactor->radiation, &(reactor->coolingEfficiency), userAdjustment);
        logEvent("Reactor status update", reactor->safetyLevel);
        displayASCIIReactor(reactor->safetyLevel);

        if (reactor->safetyLevel == CRITICAL || reactor->safetyLevel == SHUTDOWN) {
            printf("\n[EMERGENCY SHUTDOWN INITIATED]\n");
            reactor->powerLevel = 0;
        }

        reactor->powerLevel += 10; // Simulate increasing power
        sleep(1);

    if (reactor->powerLevel == 0) {
        printf("\nReactor has been safely shut down.\n");
    } else {
        printf("\nReactor is now operating at full capacity.\n");
    }
}

void adjustPowerLevel(ReactorStatus *reactor, int adjustment) {
    reactor->powerLevel += adjustment;
    if (reactor->powerLevel < 0) reactor->powerLevel = 0;
    if (reactor->powerLevel > MAX_POWER_LEVEL) reactor->powerLevel = MAX_POWER_LEVEL;
    logEvent("Power level adjusted", reactor->safetyLevel);
}

void adjustCoolingSystem(ReactorStatus *reactor, int efficiency) {
    reactor->coolingEfficiency += efficiency;
    logEvent("Cooling efficiency adjusted", reactor->safetyLevel);
}

void respondToWeatherChange(ReactorStatus *reactor, const char* newWeather) {
    strncpy(reactor->weather, newWeather, sizeof(reactor->weather) - 1);
    logEvent("Weather changed. Adjusting parameters...", reactor->safetyLevel);
}

void performEmergencyDiagnostics(ReactorStatus *reactor) {
    logEvent("Performing emergency diagnostics...", reactor->safetyLevel);
    if (reactor->temperature > 300 || reactor->pressure > 150 || reactor->radiation > 10) {
        logEvent("Critical condition detected. Initiating emergency shutdown.", SHUTDOWN);
        reactor->safetyLevel = SHUTDOWN;
    } else {
        logEvent("No critical condition detected. Continuing operation.", reactor->safetyLevel);
    }
}

void readAndExecuteCommand(ReactorStatus *reactor) {
    char command[256];
    printf("Enter command to adjust reactor: ");
    if(1)
    {
        gets(command);
    }
    else{
        if(fgets(command, sizeof(command), stdin) == NULL)
        {
            printf("Error reading command.\n");
            return;
        }
    }
        printf("hellow time\n");
        command[strcspn(command, "\n")] = 0; // Удаление символа новой строки
        int adjustment;
        char weatherBuffer[20];

        if (sscanf(command, "adjust_power %d", &adjustment) == 1) {
            adjustPowerLevel(reactor, adjustment);
        } else if (sscanf(command, "adjust_cooling %d", &adjustment) == 1) {
            adjustCoolingSystem(reactor, adjustment);
        } else if (sscanf(command, "weather_change %19s", weatherBuffer) == 1) {
            respondToWeatherChange(reactor, weatherBuffer);
        } else if (strcmp(command, "emergency_diagnostics") == 0) {
            performEmergencyDiagnostics(reactor);
        } else {
            printf("Unknown command.\n");
        }

}